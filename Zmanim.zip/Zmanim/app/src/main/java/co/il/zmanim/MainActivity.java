package co.il.zmanim;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.TextClock;

import com.example.dafyomilibrary.DafYomiCalculator;
import com.example.dafyomilibrary.DafYomiDetailes;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import co.il.zmanim.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_main);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        

        setCurrentTime();
        setCurrentEnDate();
        setTheDafYomi();


    }



    @SuppressLint("SetTextI18n")
    private void setTheDafYomi() {

        DafYomiCalculator dafYomiCalculator = new DafYomiCalculator();
        DafYomiDetailes todayDafYomiDetailes = dafYomiCalculator.getTodayDafYomi(this);

        binding.MaDafYomiTV.setText(todayDafYomiDetailes.getMasechetName() + " " + todayDafYomiDetailes.getMasechetPage());


    }


    private void setCurrentTime() {

        TextClock textClock = binding.MaTimeTC;
//        textClock.setFormat24Hour("dd MMM yyyy hh:mm:ss cccc");
//        textClock.setText(textClock.getText());


    }


    private void setCurrentEnDate() {

        String currentDate = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());

    }

}
